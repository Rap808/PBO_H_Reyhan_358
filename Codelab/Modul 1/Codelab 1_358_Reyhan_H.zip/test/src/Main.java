import java.time.LocalDate;// Memanggil fungsi ocaldate untuk mendapatkan tahun
import java.util.Scanner;//Memanggil fungsi scanner untuk menaangkap inputan

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);//Memanggil Fungsi Scanner kedalam fungsi

        String nama;
        String kelamin;
        int Tahun_lahir;

        //Scan inputan
        System.out.print("Masukkan Nama: ");
        nama = input.nextLine();
        System.out.print("Masukkan Jenis Kelamin (L/P): ");
        kelamin = input.nextLine();
        System.out.print("Masukkan Tahun Lahir : ");
        Tahun_lahir = input.nextInt();

        input.close();//Digunakan Untuk menutup Scanner
        int yearNow = LocalDate.now().getYear();//Diguakan unituk mendapatkan Tahun sekarang
        int Umur = yearNow - Tahun_lahir;
        //Percabagan untuk mencari tahu kelamin
        if (!kelamin.equals("L") && !kelamin.equals("l")) {
            if (!kelamin.equals("P") && !kelamin.equals("p")) {
                kelamin = "unknown";
            } else {
                kelamin = "Perempuan";
            }
        } else {
            kelamin = "Laki-laki";
        }
        //Output
        System.out.println("\nData Diri: ");
        System.out.format("Nama : %s\n", nama);
        System.out.format("Jenis Kelamin : %s\n", kelamin);
        System.out.format("Umur : %d Tahun\n", Umur);
    }
}
