public class Main {
    public static void main(String[] args) {
        Hewan hewan1 = new Hewan();
        Hewan hewan2 = new Hewan();
        Hewan hewan3 = new Hewan();

        hewan1.nama = "kucing";
        hewan1.jenis = "Mamalia";
        hewan1.suara = "Nyann~~";
        hewan1.warna = "Hitam";

        hewan2.nama = "Anjing";
        hewan2.jenis = "Mamalia";
        hewan2.suara = "Woof-woof";
        hewan2.warna = "Putih";

        hewan3.nama = "Ular";
        hewan3.jenis = "Reptil";
        hewan3.suara = "Mendesis";
        hewan3.warna = "Cokelat & Hijau";

        hewan1.tampilkaninfo();
        System.out.println();
        hewan2.tampilkaninfo();
        System.out.println();
        hewan3.tampilkaninfo();
    }
}