public class Hewan {
    //Membuat atribut
    String nama;
    String jenis;
    String suara;
    String warna;

    void tampilkaninfo(){
            //mengeluarkan atribut
            System.out.println("Nama    :"+nama);
            System.out.println("Jenis   :"+jenis);
            System.out.println("Suara   :"+suara);
            System.out.println("Warna   :"+warna);
    }
}
